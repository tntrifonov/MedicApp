﻿using Microsoft.AspNetCore.Identity;
using MedicApp.Domain.Entities;
using MedicApp.Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MedicApp.Application.Identity
{
    public class ApplicationUser : IdentityUser, IMedicUser
    {
    }
}
