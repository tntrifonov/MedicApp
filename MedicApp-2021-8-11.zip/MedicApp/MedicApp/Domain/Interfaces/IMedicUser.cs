﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MedicApp.Domain.Interfaces
{
    public interface IMedicUser
    {
        string Id { get; set; }
        string UserName { get; set; }
        string Email { get; set; }
    }
}
