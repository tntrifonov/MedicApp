﻿using MedicApp.Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace MedicApp.Domain.Entities
{
    public class Patient
    {
        public string Id { get; set; }
        public string Notes { get; set; }
        public bool WithHighAttention { get; set; }

        public string UserID { get; set; }
        public virtual IMedicUser User { get; set; }
        public string DoctorID { get; set; }
    }
}
