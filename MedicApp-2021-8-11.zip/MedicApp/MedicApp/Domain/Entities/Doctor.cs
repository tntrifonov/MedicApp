﻿using MedicApp.Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace MedicApp.Domain.Entities
{
    public class Doctor
    {
        public string Id { get; set; }

        public string UserID { get; set; }
        public virtual IMedicUser User { get; set; }
        public virtual ICollection<Patient> Patients { get; set; }
    }
}
