﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using MedicApp.Server.Models;

namespace MedicApp.Shared
{
    public interface IStateContainer
    {
        Doctor Doctor { get; set; }
        List<Patient> PatientList { get; set; }
        List<Patient> FilteredPatientList { get; set; }
        Patient CurrentPatient { get; set; }
        string SearchPhrase { get; set; }
        bool IsBusy { get; set; }
        Task LoadPatientListAsync();
    }
}
