﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
//using MedicApp.Core.Domain;

namespace MedicApp.Server.Models
{
    public class ApplicationUser : IdentityUser
    {
        //public virtual ICollection<Doctor> Doctors { get; set; }
        //public virtual ICollection<Patient> Patients { get; set; }
        public virtual Doctor Doctor { get; set; }
        public virtual Patient Patient { get; set; }
    }
}
