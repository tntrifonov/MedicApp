﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MedicApp.Server.Models
{
    public class Message
    {
        public string Id { get; set; }
        public string DoctorID { get; set; }
        public string PatientID { get; set; }
        public string Text { get; set; }
        public DateTime Timestamp { get; set; }
        public bool IsRead { get; set; }
        public bool IsFromDoctor { get; set; }
        public Message()
        {
            Timestamp = DateTime.Now;
            IsRead = false;
            IsFromDoctor = false;
        }
    }
}
