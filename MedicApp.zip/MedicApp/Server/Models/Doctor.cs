﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MedicApp.Server.Models
{
    public class Doctor
    {
        public string Id { get; set; }

        public string UserID { get; set; }
        public virtual ApplicationUser User { get; set; }
        public virtual ICollection<Patient> Patients { get; set; }
    }
}
