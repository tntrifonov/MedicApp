﻿using IdentityServer4.EntityFramework.Options;
using MedicApp.Server.Models;
using Microsoft.AspNetCore.ApiAuthorization.IdentityServer;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
//using MedicApp.Core.Domain;

namespace MedicApp.Server.Data
{
    public class ApplicationDbContext : ApiAuthorizationDbContext<ApplicationUser>
    {
        public DbSet<Doctor> Doctors { get; set; }
        public DbSet<Patient> Patients { get; set; }
        public ApplicationDbContext(
            DbContextOptions options,
            IOptions<OperationalStoreOptions> operationalStoreOptions) : base(options, operationalStoreOptions)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.ApplyConfiguration(new RoleConfiguration());

            modelBuilder.Entity<Doctor>()
                .HasKey(d => d.Id);
            modelBuilder.Entity<Doctor>()
                .HasMany(d => d.Patients)
                .WithOne()
                .HasForeignKey(p => p.DoctorID)
                .IsRequired();

            modelBuilder.Entity<Patient>()
                .HasKey(p => p.Id);

            modelBuilder.Entity<Message>()
                .HasKey(m => m.Id);

            modelBuilder.Entity<ApplicationUser>(b =>
            {
                    b.HasOne(au => au.Doctor)
                    .WithOne(d => d.User)
                    .OnDelete(DeleteBehavior.Cascade)
                    .HasForeignKey<Doctor>(d => d.UserID)
                    .IsRequired();

                    b.HasOne(au => au.Patient)
                    .WithOne(p => p.User)
                    .OnDelete(DeleteBehavior.Cascade)
                    .HasForeignKey<Patient>(p => p.UserID)
                    .IsRequired();
            });
        }

        public override int SaveChanges()
        {
            return base.SaveChanges();
        }
    }
}
