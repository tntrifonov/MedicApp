﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MedicApp.Server.Models;

namespace MedicApp.Server.Data
{
    public class MessageRepository : GenericRepository<Message, string>
    {
        public MessageRepository(ApplicationDbContext context) : base(context)
        {
        }
    }
}
