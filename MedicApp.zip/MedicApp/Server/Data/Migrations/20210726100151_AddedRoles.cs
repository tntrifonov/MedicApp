﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace MedicApp.Server.Data.Migrations
{
    public partial class AddedRoles : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "AspNetRoles",
                columns: new[] { "Id", "ConcurrencyStamp", "Name", "NormalizedName" },
                values: new object[] { "a0483f25-113c-4768-bf17-4e046dbd540c", "c02e528d-da56-45ab-9eda-3f8f8f0c8dbd", "Doctor", "DOCTOR" });

            migrationBuilder.InsertData(
                table: "AspNetRoles",
                columns: new[] { "Id", "ConcurrencyStamp", "Name", "NormalizedName" },
                values: new object[] { "4faf4b92-9803-4041-b3ae-7deb65446b25", "d3d935aa-83c2-49cb-9d93-36dfb81b7985", "Patient", "PATIENT" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "4faf4b92-9803-4041-b3ae-7deb65446b25");

            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "a0483f25-113c-4768-bf17-4e046dbd540c");
        }
    }
}
