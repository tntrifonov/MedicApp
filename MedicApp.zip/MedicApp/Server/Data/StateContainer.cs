﻿using MedicApp.Server.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MedicApp.Shared;

namespace MedicApp.Server.Data
{
    public class StateContainer : IStateContainer
    {
        private Doctor doctor;
        private List<Patient> patientList;
        private List<Patient> filteredPatientList;
        private Patient currentPatient;
        private string searchPhrase;
        private bool isBusy;

        public Doctor Doctor
        {
            get => doctor;
            set
            {
                doctor = value;
                NotifyStateChanged();
            }
        }

        public List<Patient> PatientList
        {
            get => patientList;
            set
            {
                patientList = value;
                NotifyStateChanged();
            }
        }

        public List<Patient> FilteredPatientList
        {
            get => filteredPatientList;
            set
            {
                filteredPatientList = value;
                NotifyStateChanged();
            }
        }

        public Patient CurrentPatient
        {
            get => currentPatient;
            set
            {
                currentPatient = value;
                NotifyStateChanged();
            }
        }

        public string SearchPhrase
        {
            get => searchPhrase;
            set
            {
                searchPhrase = value;
                UpdateFilteredPatientList();
                NotifyStateChanged();
            }
        }

        public bool IsBusy
        {
            get => isBusy;
            set
            {
                isBusy = value;
            }
        }

        public StateContainer()
        {
            PatientList = new List<Patient>();
            FilteredPatientList = new List<Patient>();
        }

        public async Task LoadPatientListAsync()
        {
            IsBusy = true;
            PatientList.Add(new Patient()
            {
                DoctorID = Guid.NewGuid().ToString(),
                Id = Guid.NewGuid().ToString(),
                Notes = "",
                WithHighAttention = true
            });
            IsBusy = false;
            UpdateFilteredPatientList();
        }

        private void UpdateFilteredPatientList()
        {

        }

        public event Action OnChange;

        private void NotifyStateChanged() => OnChange?.Invoke();
    }
}
