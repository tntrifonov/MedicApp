﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MedicApp.Server.Models;

namespace MedicApp.Server.Data
{
    public class PatientRepository : GenericRepository<Patient, string>
    {
        public PatientRepository(ApplicationDbContext context) : base(context)
        {
        }
    }
}
